package com.example.user.busticketsystem;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    String[] place={"","Dhaka","Mymensingh","Sylhet","Chittagong","Khulna","Rajshahi","Rangpur","Barisal"};
    String[] bus={"","Ena","GreenLine","Hanif","Relax","Desh"};
    String[] numb={"","1","2","3","4"};
    TextView t1,t2,t4,t7;
    Spinner sp_from,sp_to,sp_bus,sp_number;
    ArrayAdapter<String> adp;
    ArrayAdapter<String> busadp;
    ArrayAdapter<String> numberadp;
    ImageView iv1;
    Button bt1;
    RadioButton ac,noac;
    String air;
    String startnum="0", endnum="0", busnum="0", ticketnum="0", acnum="0";



    private static final String TAG = "Tickets";

    private TextView mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1=(TextView)findViewById(R.id.t1);
        t2=(TextView)findViewById(R.id.t2);
        iv1=(ImageView)findViewById(R.id.iv1);
        t4=(TextView)findViewById(R.id.t4);
        t7=(TextView)findViewById(R.id.t7);
        bt1=(Button)findViewById(R.id.b1);
        ac=(RadioButton)findViewById(R.id.ac);
        noac=(RadioButton)findViewById(R.id.noac);

        sp_from=(Spinner)findViewById(R.id.spinfrom);
        sp_to=(Spinner)findViewById(R.id.spinto);
        sp_bus=(Spinner)findViewById(R.id.spinbus);
        sp_number=(Spinner)findViewById(R.id.spin4);
        numberadp=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,numb);
        busadp=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,bus);
        sp_bus.setAdapter(busadp);
        adp=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,place);
        sp_from.setAdapter(adp);
        sp_to.setAdapter(adp);
        sp_number.setAdapter(numberadp);
//place dropdown


        sp_from.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 1:

                        t1.setText(""+place[i]);
                        startnum="1";
                        return;
                    case 2:
                        t1.setText(""+place[i]);
                        startnum="2";
                        return;
                    case 3:
                        t1.setText(""+place[i]);
                        startnum="3";
                        return;
                    case 4:
                        t1.setText(""+place[i]);
                        startnum="4";
                        return;
                    case 5:
                        t1.setText(""+place[i]);
                        startnum="5";
                        return;
                    case 6:
                        t1.setText(""+place[i]);
                        startnum="6";
                        return;
                    case 7:
                        t1.setText(""+place[i]);
                        startnum="7";
                        return;
                    case 8:
                        t1.setText(""+place[i]);
                        startnum="8";
                        return;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        sp_to.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 1:

                        t2.setText(""+place[i]);
                        endnum="1";
                        return;
                    case 2:
                        t2.setText(""+place[i]);
                        endnum="2";
                        return;
                    case 3:
                        t2.setText(""+place[i]);
                        endnum="3";
                        return;
                    case 4:
                        t2.setText(""+place[i]);
                        endnum="4";
                        return;
                    case 5:
                        t2.setText(""+place[i]);
                        endnum="5";
                        return;
                    case 6:
                        t2.setText(""+place[i]);
                        endnum="6";
                        return;
                    case 7:
                        t2.setText(""+place[i]);
                        endnum="7";
                        return;
                    case 8:
                        t2.setText(""+place[i]);
                        endnum="8";
                        return;

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

//bus dropdown

        sp_bus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 1:
                        t4.setText(""+bus[i]);
                        busnum="1";
                        iv1.setImageResource(R.drawable.ic_launcher_background);
                        break;
                    case 2:
                        t4.setText(""+bus[i]);
                        busnum="2";
                        iv1.setImageResource(R.drawable.ic_launcher_foreground);
                        break;
                    case 3:
                        t4.setText(""+bus[i]);
                        busnum="3";
                        iv1.setImageResource(R.drawable.ic_launcher_background);
                        break;
                    case 4:
                        t4.setText(""+bus[i]);
                        busnum="4";
                        iv1.setImageResource(R.drawable.ic_launcher_background);
                        break;
                    case 5:
                        t4.setText(""+bus[i]);
                        busnum="5";
                        iv1.setImageResource(R.drawable.ic_launcher_foreground);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

//Ticket Number

        sp_number.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 1:
                        t7.setText(""+numb[i]);
                        ticketnum="1";
                        break;
                    case 2:
                        t7.setText(""+numb[i]);
                        ticketnum="2";
                        break;
                    case 3:
                        t7.setText(""+numb[i]);
                        ticketnum="3";
                        break;
                    case 4:
                        t7.setText(""+numb[i]);
                        ticketnum="4";
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



//date set
        mDisplayDate = (TextView) findViewById(R.id.t3);

        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        MainActivity.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                String date = month + "/" + day + "/" + year;
                mDisplayDate.setText(date);
            }
        };


//Button action


        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ac.isChecked()){
                    air="AC";
                    acnum="1";

                }

                else if(noac.isChecked()){

                    air="Non AC";
                    acnum="2";
                }
                else {
                    air="Not Selected";
                    acnum="3";

                }
                String from_name=t1.getText().toString();
                String to_name=t2.getText().toString();
                String date= mDisplayDate.getText().toString();
                String bus= t4.getText().toString();
                String ticketnumber=t7.getText().toString();

                Intent go=new Intent(MainActivity.this, Second.class);
                go.putExtra("FROM", from_name);
                go.putExtra("TO", to_name);
                go.putExtra("DATE", date);
                go.putExtra("BUS", bus);
                go.putExtra("AIR", air);
                go.putExtra("NUMBER_OF_TICKET",ticketnumber);

                //number send

                go.putExtra("START_NUM", startnum);
                go.putExtra("END_NUM", endnum);
                go.putExtra("BUS_NUM", busnum);
                go.putExtra("AC_NUM", acnum);
                go.putExtra("TICKET_NUM", ticketnum);

                startActivity(go);
            }
        });

    }

}


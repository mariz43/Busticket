package com.example.user.busticketsystem;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Second extends AppCompatActivity {
    private static final int REQUEST_CALL = 1;
    TextView tt1,t1,t2,t3,t4,t5,t6;
    EditText et1;
    TextView ht1,ht2,ht3,ht4,ht5;
    int cost;
    Button sms,icall;
    int strt_place,end_place,busname,ac_nonac,number_of_ticket;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tt1=(TextView)findViewById(R.id.tt1);
        t1=(TextView)findViewById(R.id.t1);
        t2=(TextView)findViewById(R.id.t2);
        t3=(TextView)findViewById(R.id.t3);
        t4=(TextView)findViewById(R.id.t4);
        t5=(TextView)findViewById(R.id.t5);
        t6=(TextView)findViewById(R.id.t6);
        sms=(Button)findViewById(R.id.b1);
        icall=(Button)findViewById(R.id.b2);
        et1=(EditText)findViewById(R.id.et1);

        //hiden textview

        ht1=(TextView)findViewById(R.id.ht1);
        ht2=(TextView)findViewById(R.id.ht2);
        ht3=(TextView)findViewById(R.id.ht3);
        ht4=(TextView)findViewById(R.id.ht4);
        ht5=(TextView)findViewById(R.id.ht5);

        tt1.setText("You Want to Travel From "+getIntent().getStringExtra("FROM")+" To "
                +getIntent().getStringExtra("TO")+" On date "+getIntent().getStringExtra("DATE")+" By "
                +getIntent().getStringExtra("BUS")+" Bus.");
        t1.setText(""+getIntent().getStringExtra("FROM"));
        t2.setText(""+getIntent().getStringExtra("TO"));
        t3.setText(""+getIntent().getStringExtra("DATE"));
        t4.setText(""+getIntent().getStringExtra("BUS"));
        t5.setText(""+getIntent().getStringExtra("AIR"));
        t6.setText(""+getIntent().getStringExtra("NUMBER_OF_TICKET"));


        //set to hidentext
        ht1.setText(""+getIntent().getStringExtra("START_NUM"));
        ht2.setText(""+getIntent().getStringExtra("END_NUM"));
        ht3.setText(""+getIntent().getStringExtra("BUS_NUM"));
        ht4.setText(""+getIntent().getStringExtra("AC_NUM"));
        ht5.setText(""+getIntent().getStringExtra("TICKET_NUM"));

        strt_place=Integer.parseInt(ht1.getText().toString());
        end_place=Integer.parseInt(ht2.getText().toString());
        busname=Integer.parseInt(ht3.getText().toString());
        ac_nonac=Integer.parseInt(ht4.getText().toString());
        number_of_ticket=Integer.parseInt(ht5.getText().toString());



        sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                if (ContextCompat.checkSelfPermission(Second.this, Manifest.permission.SEND_SMS)
                        != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(Second.this, new String [] {Manifest.permission.SEND_SMS},
                            1);
                }else{
                    SmsManager sms=SmsManager.getDefault();
                    sms.sendTextMessage("+8801866576195", null, "Client name: "+et1.getText().toString()+
                            "\nRoute: "+t1.getText().toString()+" to "+t2.getText().toString()+
                            "\nTravel Date: "+t3.getText().toString()+"\nBy: "+t4.getText().toString()+ "  " +
                            " Type: "+t5.getText().toString()+
                            "\nNumber Of Ticket: "+t6.getText().toString(), null,null);

                    Toast.makeText(getApplicationContext(), "Message Sent successfully!", Toast.LENGTH_LONG).show();}
            }
        });


        icall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makePhoneCall();
            }
        });
    }

    private void makePhoneCall() {
        String number = "01749211711";
        if (number.trim().length() > 0) {

            if (ContextCompat.checkSelfPermission(Second.this,
                    Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(Second.this,
                        new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL);
            } else {
                String dial = "tel:" + number;
                startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
            }

        }
    }
}

